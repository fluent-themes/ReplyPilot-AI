<?php
require __DIR__.'/../bootstrap.php';
if (!defined('INSTALL_FALLBACK_TOKEN')) define('INSTALL_FALLBACK_TOKEN','setup123');
\App\Installer\Installer::run();
?>
