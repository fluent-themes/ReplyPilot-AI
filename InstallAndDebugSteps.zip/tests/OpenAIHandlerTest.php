<?php
use PHPUnit\Framework\TestCase;
use App\Services\OpenAIHandler;

class OpenAIHandlerTest extends TestCase {
    public function testPromptBuild(){
        $p = OpenAIHandler::buildSmartPrompt('Hello','friendly','DemoProduct');
        $this->assertStringContainsString('DemoProduct',$p);
        $this->assertStringContainsString('Hello',$p);
    }
}
?>
