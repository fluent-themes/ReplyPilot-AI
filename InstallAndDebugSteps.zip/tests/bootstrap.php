<?php
require __DIR__.'/../vendor/autoload.php';

use App\Core\Env;
Env::load(__DIR__.'/../.env.example');   // use example env
// Use in-memory sqlite for faster isolated tests
putenv('DB_DSN=sqlite::memory:');
?>
