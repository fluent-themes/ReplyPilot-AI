<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Env;
use App\Core\Request;
use App\Core\Response;
use App\Repository\SubmissionRepository;
use App\Repository\SubmissionRepositoryMock;
use App\Services\LicenseValidator;
use App\Services\OpenAIHandler;
use App\Services\OpenAIHandlerMock;
use App\Support\Mailer;
use App\Support\MailerMock;

$logger = $GLOBALS['container']['logger'];
$db     = $GLOBALS['container']['db'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim(Request::input('name'));
    $email = trim(Request::input('email'));
    $msg   = trim(Request::input('message'));
    $tone  = trim(Request::input('tone', 'friendly'));
    $purchase = trim(Request::input('purchase_code', ''));
    [$valid, $productName] = LicenseValidator::validate($purchase);
    if (!$valid && $purchase !== '') {
        $error = 'Invalid purchase code';
    }
    if (empty($error)) {
        $prompt = OpenAIHandler::buildSmartPrompt($msg, $tone, $productName ?? 'Your Product');
        $useAiMock = Env::get('OPENAI_API_KEY') === 'MOCK_MODE';
        // PRODUCTION NOTE:
        // To enable real OpenAI: set a real OPENAI_API_KEY in .env (not 'MOCK_MODE')
        $aiService = $useAiMock ? OpenAIHandlerMock::class : OpenAIHandler::class;
        $ai = $aiService::query($prompt);

        $useRepoMock = Env::get('DB_CONNECTION') === 'none';
        // PRODUCTION NOTE:
        // To enable real DB: set DB_CONNECTION and DB_* variables in .env
        $repo = $useRepoMock ? new SubmissionRepositoryMock($db) : new SubmissionRepository($db);
        $repo->save([
            'name' => $name,
            'email' => $email,
            'message' => $msg,
            'tone' => $tone,
            'purchase_code' => $purchase,
            'product_name' => $productName ?? '',
            'category' => $ai['category'],
            'ai_reply' => $ai['reply']
        ]);

        $useMailerMock = Env::get('MAIL_TRANSPORT') === 'file';
        // PRODUCTION NOTE:
        // To send real mail: set MAIL_TRANSPORT=smtp and SMTP_* variables in .env
        $mailer = $useMailerMock ? new MailerMock() : new Mailer();
        $mailer->send($email, 'Your Reply from AI', $ai['reply']);
        header('Location: thank-you.php');
        exit;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact Support — ReplyPilot</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <script src="assets/js/main.js" defer></script>
</head>
<body>
  <main class="container">
    <div class="card" style="max-width: 760px; margin: 0 auto;">
      <div class="card-body">
        <h1 style="margin:0 0 8px">Contact Support</h1>
        <p style="margin:0 0 18px; color:var(--muted)">We typically respond within 1–2 business days.</p>

        <form method="post" action="">
          <?php if(!empty($error)): ?>
            <div class="note danger"><?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <div class="form-row">
            <div>
              <label for="f-name">Name</label>
              <input id="f-name" name="name" required>
            </div>
            <div>
              <label for="f-email">Email</label>
              <input id="f-email" type="email" name="email" required>
            </div>
          </div>

          <label for="f-message">Message</label>
          <textarea id="f-message" name="message" required rows="7"></textarea>

          <div class="form-row">
            <div>
              <label for="f-product">Product Name</label>
              <input id="f-product" name="product_name">
            </div>
            <div>
              <label for="f-tone">Tone</label>
              <select id="f-tone" name="tone">
                <option value="friendly">Friendly</option>
                <option value="professional">Professional</option>
              </select>
            </div>
          </div>

          <label for="f-purchase">Purchase Code (optional)</label>
          <input id="f-purchase" name="purchase_code">

          <div style="margin-top:16px; display:flex; gap:10px; flex-wrap:wrap">
            <button class="btn primary" type="submit">Send</button>
            <button class="btn ghost" type="reset">Reset</button>
          </div>
        </form>
      </div>
    </div>
  </main>
</body>
</html>
