<?php
require __DIR__ . '/guard.php';

use App\Support\Mailer;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ./');
    exit;
}

$id      = (int)($_POST['id'] ?? 0);
$to      = trim($_POST['to'] ?? '');
$subject = trim($_POST['subject'] ?? '');
$body    = trim($_POST['body'] ?? '');

if (!$to || !$subject || !$body) {
    header('Location: ./?status=invalid');
    exit;
}

$mailer = new Mailer();
$ok = $mailer->send($to, $subject, $body);

header('Location: ./?status=' . ($ok ? 'sent' : 'failed') . ($id ? "#row-$id" : ''));
exit;
