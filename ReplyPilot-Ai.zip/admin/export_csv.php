<?php
require __DIR__ . '/guard.php';

$db = $GLOBALS['container']['db'];
$stmt = $db->query('SELECT id,name,email,message,tone,purchase_code,product_name,category,ai_reply,created_at FROM submissions ORDER BY id DESC');
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="submissions.csv"');

$out = fopen('php://output', 'w');
fputcsv($out, array_keys($rows[0] ?? [
    'id','name','email','message','tone','purchase_code','product_name','category','ai_reply','created_at'
]));

foreach ($rows as $r) {
    // Normalize newlines to avoid CSV breakage
    foreach (['message','ai_reply'] as $k) {
        if (isset($r[$k])) {
            $r[$k] = preg_replace("/\r\n|\r|\n/", " ", (string) $r[$k]);
        }
    }
    fputcsv($out, $r);
}
fclose($out);
