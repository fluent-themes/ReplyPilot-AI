<?php
require __DIR__ . '/guard.php';

use App\Support\Mailer;
use App\Core\Env;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ./');
    exit;
}

$id        = (int)($_POST['id'] ?? 0);
$ai_reply  = trim($_POST['ai_reply'] ?? '');
$category  = trim($_POST['category'] ?? '');
$send      = isset($_POST['send']) && $_POST['send'] === '1';
$to        = trim($_POST['to'] ?? '');
$subject   = trim($_POST['subject'] ?? '');
$body      = trim($_POST['body'] ?? '');

if ($id <= 0) {
    header('Location: ./?status=invalid');
    exit;
}

$db = $GLOBALS['container']['db'];
// Update reply and category
$stmt = $db->prepare("UPDATE submissions SET ai_reply = ?, category = ? WHERE id = ?");
$stmt->execute([$ai_reply, $category, $id]);

$status = 'updated';

if ($send && $to && $subject && $body) {
    $mailer = new Mailer();
    $ok = $mailer->send($to, $subject, $body);
    $status = $ok ? 'updated_sent' : 'updated_send_failed';
}

header("Location: ./?status={$status}#row-$id");
exit;
