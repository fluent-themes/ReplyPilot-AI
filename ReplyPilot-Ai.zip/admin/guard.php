<?php
require __DIR__ . '/../bootstrap.php';

use App\Core\Env;

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$valid = isset($_SESSION['admin_ok']) && $_SESSION['admin_ok'] === true;
$token = $_GET['token'] ?? null;
if (!$valid) {
    if ($token && $token === Env::get('INSTALL_TOKEN')) {
        $_SESSION['admin_ok'] = true;
        // Redirect to the same page without token in URL
        $url = strtok($_SERVER['REQUEST_URI'], '?');
        header("Location: $url");
        exit;
    }
    http_response_code(403);
    echo 'Admin access requires a valid token. Append <code>?token=YOUR_INSTALL_TOKEN</code> once to unlock this session.';
    exit;
}
